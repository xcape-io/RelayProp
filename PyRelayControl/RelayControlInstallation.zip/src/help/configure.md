﻿To configure the Relay prop:

1. Choose Arduino or Raspberry board model
2. Set board option if any (Dragino Yún shield or MCP23017 expander)
3. Edit prop MQTT topics (inbosd/outbox/wiring)
4. Set MQTT broker IP address and port 

At first start, when choosing board model:

* prop name is filled with a default name
* inbox topic is filled with *xcape.io* recommandations
* outbox topic is filled as well
* wiring topic is filled too