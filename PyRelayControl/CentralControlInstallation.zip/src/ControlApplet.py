#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ControlApplet.py
MIT License (c) Marie Faure <dev at faure dot systems>

ControlApplet application extends MqttApplet.
"""

from constants import *
from MqttApplet import MqttApplet
from ControlDialog import ControlDialog
from ControlSettingsDialog import ControlSettingsDialog
from PyQt5.QtCore import pyqtSignal, pyqtSlot
import os, sys
import codecs
import configparser

class ControlApplet(MqttApplet):

    # __________________________________________________________________
    def __init__(self, argv, client, debugging_mqtt=False):
        super().__init__(argv, client, debugging_mqtt)

        self.setApplicationDisplayName(APPDISPLAYNAME)

        self._propSettings = configparser.ConfigParser()
        prop_ini = 'prop.ini'
        if os.path.isfile(prop_ini):
            self._propSettings.read_file(codecs.open(prop_ini, 'r', 'utf8'))

        if 'prop' not in self._propSettings.sections():
            self._propSettings.add_section('prop')

        if 'board' not in self._propSettings['prop']:
            dlg = ControlSettingsDialog(self._propSettings, self._logger)
            dlg.setModal(True)
            dlg.exec()

            with open('prop.ini', 'w') as configfile:
                self._propSettings.write(configfile)

        if 'board' not in self._propSettings['prop']:
            self._logger.info(self.tr("Central prop board is not configured"))
            # no event loop to quit
            sys.exit()

        if 'broker_address' in self._propSettings['prop']:
            self._mqttServerHost = self._propSettings['prop']['broker_address']

        if 'broker_port' in self._propSettings['prop']:
            self._mqttServerPort = int(self._propSettings['prop']['broker_port'])

        if 'prop_outbox' in self._propSettings['prop']:
            self._mqttSubscriptions.append(self._propSettings['prop']['prop_outbox'])

        self._PanelDialog = ControlDialog(self.tr("Control"), './x-relay.png',
                                        self._definitions['mqtt-pub-prop'],
                                        self._definitions['mqtt-sub-prop'],
                                        self._logger)
        self._PanelDialog.aboutToClose.connect(self.exitOnClose)
        self._PanelDialog.publishMessage.connect(self.publishMessage)

        self.connectedToMqttBroker.connect(self._PanelDialog.onConnectedToMqttBroker)
        self.disconnectedToMqttBroker.connect(self._PanelDialog.onDisconnectedToMqttBroker)
        self.messageReceived.connect(self._PanelDialog.onMessageReceived)

        self._PanelDialog.show()

    # __________________________________________________________________
    @pyqtSlot()
    def exitOnClose(self):
        self._logger.info(self.tr("exitOnClose "))
        self.quit()
