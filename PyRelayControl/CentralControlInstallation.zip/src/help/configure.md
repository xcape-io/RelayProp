﻿To configure the central prop:

1. Choose Arduino or Raspberry board model
2. Set board option
3. Enter prop name, then press tab:
    * inbox is filled with *xcape.io* recommandation
    * outbox is filled as well
    * settings is filled too
4. Set MQTT broker IP address and port 

